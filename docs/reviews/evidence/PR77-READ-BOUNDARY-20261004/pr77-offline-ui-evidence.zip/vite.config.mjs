import { defineConfig } from '/workspace/medical-pr74-evidence/web/node_modules/vite/dist/node/index.js'
import react from '/workspace/medical-pr74-evidence/web/node_modules/@vitejs/plugin-react/dist/index.js'
import tailwindcss from '/workspace/medical-pr74-evidence/web/node_modules/@tailwindcss/vite/dist/index.mjs'
export default defineConfig({
  root: '/workspace/scratch/pr77-ui-20261004',
  plugins: [react(), tailwindcss()],
  resolve: { alias: { '@': '/workspace/medical-pr74-evidence/web/src', react: '/workspace/medical-pr74-evidence/web/node_modules/react', 'react-dom': '/workspace/medical-pr74-evidence/web/node_modules/react-dom', 'lucide-react': '/workspace/medical-pr74-evidence/web/node_modules/lucide-react' } },
  define: { __BUILD_COMMIT__: JSON.stringify('c408cda90f7cbc38da66c4270edcac20a29cd793') },
  server: { host: '127.0.0.1', port: 4177, strictPort: true, fs: { allow: ['/workspace/scratch/pr77-ui-20261004', '/workspace/medical-pr74-evidence/web'] } },
})
