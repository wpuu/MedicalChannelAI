import React, { useEffect, useState } from 'react'
import { BrowserRouter } from 'react-router-dom'
import { createRoot } from 'react-dom/client'
import './style.css'
import { LegalWindowNotice } from '@/components/shared/LegalWindowNotice'
import { AwardPriceReferenceSection } from '@/components/shared/AwardPriceReferenceSection'
import { AwardPriceReferenceNotice } from '@/components/shared/AwardPriceReferenceNotice'
import { AwardResultNotice } from '@/components/shared/AwardResultNotice'
import { ApiTodayActionsService } from '@/services/ApiTodayActionsService'
import { AwardLedgerSection } from '@/components/shared/AwardLedgerSection'
import { ActionCard } from '@/components/today/ActionCard'
import { getVerifiedOpportunityPool, getAwardPriceReference, findAwardForProject } from '@/services/verifiedOpportunityPool'

function Harness() {
  const [api, setApi] = useState<any>(null)
  const [rejected, setRejected] = useState('')
  const [pool, setPool] = useState<any>(null)
  const [reference, setReference] = useState<any>(null)
  const [page, setPage] = useState('紧凑列表')
  const [error, setError] = useState('')
  useEffect(() => {
    new ApiTodayActionsService('/offline-api').getTodayActions().then(setApi).catch(e => setError(String(e)))
    new ApiTodayActionsService('/offline-retired').getTodayActions().then(() => setRejected('错误接受')).catch(e => setRejected(String(e)))
    Promise.all([getVerifiedOpportunityPool(), getAwardPriceReference()])
      .then(([p, r]) => { setPool(p); setReference(r.reference) })
      .catch((e) => setError(String(e)))
  }, [])
  if (error) return <pre role="alert">{error}</pre>
  if (!pool) return <p>加载本地合成 fixture…</p>
  const card = pool.cards[0]
  const unknown = pool.award_ledger.find((e:any) => e.project_number === 'MARKETLESS-002')
  const partial = pool.award_ledger.find((e:any) => e.project_number === 'PARTIAL-001')
  const mismatch = findAwardForProject(pool.award_ledger, 'MARKETLESS-002', 'HE')
  return <main className="mx-auto max-w-5xl space-y-4 p-4">
    <header className="rounded-xl border border-amber-300 bg-amber-50 p-3 text-sm"><h1 className="font-semibold">PR77 · 本地离线 UI 验证</h1><p>全部为清楚标注的合成 fixture。没有客户数据、生产数据库、外网采集或模型调用。</p></header>
    <nav className="flex flex-wrap gap-2">{['紧凑列表','完整详情','今日行动卡','价格参考','API 旧证据'].map((name) => <button key={name} className="rounded-lg border bg-white px-3 py-2 text-sm" onClick={() => setPage(name)}>{name}</button>)}</nav>
    <div className="rounded-xl border bg-white p-3 text-sm" data-testid="pool-proof">保留项目：{pool.cards.length} / 2；整项目退役：{pool.awarded_project_count}；缺市场跨市场匹配：{mismatch ? '错误匹配' : '无匹配'}</div>
    <h2 className="font-semibold">{page}</h2>
    {page === '紧凑列表' ? <section className="space-y-3" data-testid="compact">{pool.cards.map((c:any) => <article key={c.opportunity_id} className="rounded-xl border bg-white p-3"><h3 className="mb-2 text-sm font-medium">{c.facts.project_name}</h3><LegalWindowNotice card={c} compact /></article>)}</section> : null}
    {page === '完整详情' ? <section className="space-y-4" data-testid="full"><LegalWindowNotice card={card}/><AwardResultNotice entry={partial}/><div className="rounded-xl border bg-white p-3 text-sm">缺 market 的结果单独展示，不能匹配河北项目：{unknown.project_number}</div><AwardPriceReferenceNotice card={card} reference={reference}/></section> : null}
    {page === '今日行动卡' ? <ActionCard card={card} onDetail={() => setPage('完整详情')} onContacted={() => {}} onFollow={() => {}} onNotFit={() => {}} onRemind={() => {}} onOutreach={() => {}} automationUnavailableReason="离线验证：不执行业务写入或模型调用" analysisUnavailableReason="离线验证：不调用模型" /> : null}
    {page === 'API 旧证据' && api ? <section data-testid="api-mode" className="space-y-4"><p data-testid="api-proof">旧退役快照拒收：{rejected.includes('AWARD_EVIDENCE_LEGACY_RETIRED_POOL') ? '是' : rejected}；卡片窗口：{api.cards[0].legal_windows[0].status}；池窗口：{api.opportunity_pool[0].legal_windows[0].status}；结果窗口：{api.award_ledger[0].legal_windows[0].status}；总额：{String(api.award_ledger[0].total_amount_cny)}；包额：{String(api.award_ledger[0].packages[0].amount_cny)}；单价：{String(api.award_ledger[0].items[0].unit_price_cny)}</p><AwardLedgerSection entries={api.award_ledger}/><AwardResultNotice entry={api.award_ledger[0]}/><ActionCard card={api.cards[0]} onDetail={() => {}} onContacted={() => {}} onFollow={() => {}} onNotFit={() => {}} onRemind={() => {}} onOutreach={() => {}} automationUnavailableReason="离线验证" analysisUnavailableReason="离线验证" /></section> : null}
    {page === '价格参考' ? <div data-testid="prices"><p className="text-sm">输入包含明确单位、缺单位及矛盾单位的 3 行；实际参考只保留明确单位行。</p><AwardPriceReferenceSection reference={reference}/></div> : null}
  </main>
}
createRoot(document.getElementById('root')!).render(<BrowserRouter><Harness /></BrowserRouter>)
